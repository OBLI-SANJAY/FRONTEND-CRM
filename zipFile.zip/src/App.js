import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";

import Front from "./FrontPage";
import Login from "./Login";
import SignUp from "./Signup";


import Dashboard from "./Dashboard";
import Leads from "./Leads";
import AddLead from "./AddLead";
import LeadDetails from "./LeadDetails";

import Customers from "./Customers";
import CustomerDetails from "./CustomerDetails";
import EditCustomer from "./EditCustomer";

import Tasks from "./Tasks";
import AddTask from "./AddTask";
import EditTask from "./EditTask";

import Settings from "./Settings";

function App() {
  const role = localStorage.getItem("role");

  return (
    <Routes>

      {/* LANDING */}
      <Route path="/" element={<Front />} />

      {/* AUTH */}
      <Route path="/login" element={<Login />} />
      <Route path="/signup" element={<SignUp /> }/>
      

      {/* DASHBOARD */}
      <Route
        path="/dashboard"
        element={role ? <Dashboard /> : <Navigate to="/login" />}
      />

      {/* LEADS */}
      <Route
        path="/leads"
        element={role ? <Leads /> : <Navigate to="/login" />}
      />
      <Route
        path="/leads/new"
        element={role ? <AddLead /> : <Navigate to="/login" />}
      />
      <Route
        path="/leads/:id"
        element={role ? <LeadDetails /> : <Navigate to="/login" />}
      />

      {/* CUSTOMERS */}
      <Route
        path="/customers"
        element={role ? <Customers /> : <Navigate to="/login" />}
      />
      <Route
        path="/customers/:id"
        element={role ? <CustomerDetails /> : <Navigate to="/login" />}
      />
      <Route
        path="/customers/:id/edit"
        element={role ? <EditCustomer /> : <Navigate to="/login" />}
      />

      {/* TASKS */}
      <Route
        path="/tasks"
        element={role ? <Tasks /> : <Navigate to="/login" />}
      />
      <Route
        path="/tasks/new"
        element={role ? <AddTask /> : <Navigate to="/login" />}
      />
      <Route
        path="/tasks/:id/edit"
        element={role ? <EditTask /> : <Navigate to="/login" />}
      />

      {/* SETTINGS → Manager & Employee only */}
      <Route
        path="/settings"
        element={
          role === "Manager" || role === "Employee"
            ? <Settings />
            : <Navigate to="/dashboard" />
        }
      />

    </Routes>
  );
}

export default App;
