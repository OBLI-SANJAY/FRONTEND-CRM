import React from "react";
import { useNavigate, Link } from "react-router-dom";
import "./AddLead.css";

function AddLead() {
  const navigate = useNavigate();

  return (
    <div className="dashboard">
      <aside className="sidebar">
        <h2 className="logo">ClientConnect</h2>

        <nav className="menu">
          <Link to="/dashboard">Dashboard</Link>
          <Link to="/leads" className="active">Leads</Link>
          <Link to="/customers">Customers</Link>
          <Link to="/tasks">Tasks</Link>
          <Link to="/settings">Settings</Link>
        </nav>

        <div className="sidebar-footer">
          <button
            className="logout-btn"
            onClick={() => navigate("/login")}
          >
            ← Log Out
          </button>

          <div className="user-info">
            <div className="avatar">S</div>
            <div>
              <p className="name">Sanjay</p>
              {/* Role removed */}
            </div>
          </div>
        </div>
      </aside>

      <main className="content">
        <div className="breadcrumb">
          Leads <span>›</span> New Lead
        </div>

        <h1 className="page-title">Add New Lead</h1>

        <div className="form-card">
          <div className="form-group">
            <label>Full Name</label>
            <input type="text" placeholder="e.g. John Doe" />
          </div>

          <div className="form-row">
            <div className="form-group">
              <label>Company</label>
              <input type="text" placeholder="e.g. Tech Solutions Inc." />
            </div>

            <div className="form-group">
              <label>Status</label>
              <select>
                <option>New Lead</option>
                <option>Qualified</option>
                <option>Negotiation</option>
                <option>Contacted</option>
              </select>
            </div>
          </div>

          <h4 className="section-title">Contact Details</h4>

          <div className="form-group">
            <label>Email Address</label>
            <input type="email" placeholder="john@example.com" />
          </div>

          <div className="form-group">
            <label>Phone Number</label>
            <input type="text" placeholder="+1 (555) 000-0000" />
          </div>

          <div className="form-group">
            <label>Additional Notes</label>
            <textarea placeholder="Add any relevant details..." />
          </div>

          <div className="form-actions">
            <button
              className="cancel-btn"
              onClick={() => navigate("/leads")}
            >
              Cancel
            </button>

            <button
              className="save-btn"
              onClick={() => navigate("/leads")}
            >
              Save Lead
            </button>
          </div>
        </div>
      </main>
    </div>
  );
}

export default AddLead;